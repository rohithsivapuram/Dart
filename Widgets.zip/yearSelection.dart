import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class yearDropDown extends StatefulWidget{
  Function HANDLE;
  yearDropDown(this.HANDLE);
  @override
  State<StatefulWidget> createState() {
    return yearDropDownState(HANDLE);
  }

}

class yearDropDownState extends State<yearDropDown>{

  Function HANDLE;
  yearDropDownState(this.HANDLE);

  String dropDownValue = "None";
  List<String> options  = ["None","Prediction", "2020", "2019", "2018", "arrivals"];
  @override
  Widget build(BuildContext context) {

    return DropdownButton<String>(

      value : dropDownValue,
      icon: Icon(Icons.arrow_drop_down_circle_sharp,),
      iconSize: 20,
      elevation: 10,
      style: TextStyle(color: Colors.green,),
      underline: Container(height: 1,color: Colors.green,),
      onChanged: (String value){
        dropDownValue = value;
        HANDLE(dropDownValue);
        setState(() {});
      },
      items: options.map<DropdownMenuItem<String>>((String value){

        return DropdownMenuItem(value:value,child: Text(value));

      }).toList(),
    );


  }




}