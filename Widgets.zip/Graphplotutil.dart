import "dart:convert";

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'Graph.dart';

// ignore: must_be_immutable, camel_case_types
class graph_plot_Util extends StatelessWidget {
  List<timeseries> _prediction = [];
  List<timeseries> _arrival = [];
  List<timeseries> _minPrice = [];
  List<timeseries> _maxPrice = [];
  List<timeseries> _modalPrice = [];

  String _data;
  List<String> _dataList = [];

  graph_plot_Util(this._data) {
    if (_data != "") {
      _dataList = _data.split("\n");
      DateTime date;
      var price;
      List sepList;
      for (var timeData in _dataList) {
        sepList = timeData.split(":");
        date = DateTime.parse(sepList[0]);
        price = json.decode(sepList[1]);
        _arrival.add(timeseries(date: date, price: price[0].toDouble()));
        _minPrice.add(timeseries(date: date, price: price[1].toDouble()));
        _maxPrice.add(timeseries(date: date, price: price[2].toDouble()));
        _modalPrice.add(timeseries(date: date, price: price[3].toDouble()));
      }
    }
  }

  graph_plot_Util.singleValue(this._data) {
    if (_data != "") {
      _dataList = _data.split("\n");
      var date, price, sepList;
      for (var time_data in _dataList) {
        sepList = time_data.split(":");
        print(DateTime.parse(sepList[0]));
        date = DateTime.parse(sepList[0]);
        price = double.parse(sepList[1]);
        _prediction.add(timeseries(date: date, price: price));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Card(
        child: plotChart(
      arrivals: _arrival,
      maxPrice: _maxPrice,
      minPrice: _minPrice,
      modalPrice: _modalPrice,
      prediction: _prediction,
    ));
    // );/*timegraph(*//**//*Data,Data2,Data3*//*)**/
  }
}

class timeseries {
  DateTime date;
  double price;
  Color color = Colors.deepOrange;

  timeseries({this.date, this.price});
}
