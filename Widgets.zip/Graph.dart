import 'package:flutter/cupertino.dart';
import 'package:raita_vahini/Widgets/Graphplotutil.dart';
import "package:syncfusion_flutter_charts/charts.dart";

class plotChart extends StatelessWidget {
  List<timeseries> prediction;
  List<timeseries> arrivals;
  List<timeseries> modalPrice;
  List<timeseries> maxPrice;
  List<timeseries> minPrice;

  plotChart(
      {this.maxPrice,
      this.minPrice,
      this.modalPrice,
      this.arrivals,
      this.prediction});

  plotChart.single(this.prediction);

  @override
  Widget build(BuildContext context) {
    return SfCartesianChart(
        trackballBehavior:
            TrackballBehavior(enable: true, lineColor: Color(0xFF01011D)),
        enableAxisAnimation: true,
        primaryXAxis: DateTimeAxis(),
        series: <ChartSeries<timeseries, DateTime>>[
          SplineSeries<timeseries, DateTime>(
              dataSource: prediction,
              xValueMapper: (timeseries data, _) => data.date,
              yValueMapper: (timeseries data, _) => data.price,
              animationDuration: 2000,
              markerSettings: MarkerSettings(isVisible: true,width: 6, height: 6)),
          SplineSeries<timeseries, DateTime>(
            dataSource: maxPrice,
            xValueMapper: (timeseries data, _) => data.date,
            yValueMapper: (timeseries data, _) => data.price,
            animationDuration: 2000,
            markerSettings: MarkerSettings(isVisible: true,width: 6, height: 6),
          ),
          SplineSeries<timeseries, DateTime>(
              dataSource: minPrice,
              xValueMapper: (timeseries data, _) => data.date,
              yValueMapper: (timeseries data, _) => data.price,
              animationDuration: 2000,
              markerSettings: MarkerSettings(isVisible: true,width: 6, height: 6)),
          SplineSeries<timeseries, DateTime>(
              dataSource: modalPrice,
              xValueMapper: (timeseries data, _) => data.date,
              yValueMapper: (timeseries data, _) => data.price,
              animationDuration: 2000,
              markerSettings: MarkerSettings(isVisible: true,width: 6, height: 6)),
          SplineSeries<timeseries, DateTime>(
              dataSource: arrivals,
              xValueMapper: (timeseries data, _) => data.date,
              yValueMapper: (timeseries data, _) => data.price,
              animationDuration: 2000,
              markerSettings: MarkerSettings(isVisible: true,width: 6, height: 6)),
        ]);
  }
}
