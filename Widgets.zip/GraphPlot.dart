import "package:flutter/material.dart";
import 'package:flutter/services.dart' show rootBundle;
import 'package:raita_vahini/Widgets/yearSelection.dart';

import 'Graphplotutil.dart';

class graphData extends StatefulWidget {
  final String _commodity;
  final String _period;

  graphData(this._commodity, this._period);

  @override
  State<StatefulWidget> createState() {
    return GraphplotState(_commodity, _period);
  }
}

class GraphplotState extends State<graphData> {
  String _path = "assets/DATA/";
  String _graph_Options = "";
  String predicted = "",
      price2020 = "",
      price2019 = "",
      price2018 = "",
      price2017 = "";

  String _commodity;
  final String _period;

  // ignore: non_constant_identifier_names
  Map<String, String> _Predction_length = {
    "1 week": "week1_",
    "2 weeks": "week2_",
    "3 weeks": "week3_",
    "4 weeks": "week4_",
    "1 month": "week5_",
  };

  GraphplotState(this._commodity, this._period) {
    _commodity = _commodity.replaceAll('\r', "");
    _commodity += "_";
    _path += _commodity + _Predction_length[_period];
    _loadData(_path);
  }

  set set_yearValue(String year) => _graph_Options = year;

  Future<void> _loadData(String path) async {
    predicted = await rootBundle.loadString(path + "predicted.txt");
    price2020 = await rootBundle.loadString(path + "price2020.txt");
    price2019 = await rootBundle.loadString(path + "price2019.txt");
    price2018 = await rootBundle.loadString(path + "price2018.txt");
    // price2017 = await rootBundle.loadString(path + "price2017.txt");
    setState(() {});
  }

  void set_option_dropdown(String value) {
    switch (value) {
      case "Prediction":
        _graph_Options = predicted;
        break;
      case "2020":
        _graph_Options = price2020;
        break;
      case "2019":
        _graph_Options = price2019;
        break;
      case "2018":
        _graph_Options = price2018;
        break;
      default:
        _graph_Options = "";
    }
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
          appBar: AppBar(),
          body: ListView(
            padding: EdgeInsets.all(20),
            physics: BouncingScrollPhysics(),
            children: [
              Align(
                alignment: Alignment.topRight,
                child: yearDropDown(set_option_dropdown),
              ),
              SizedBox(height: 30,),
              Card(shape:RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),child: Container(height:450,padding: EdgeInsets.all(10),
                  child: _graph_Options == predicted
                      ? graph_plot_Util.singleValue(_graph_Options)
                      : graph_plot_Util(_graph_Options)),
              shadowColor: Colors.blue,
              elevation: 20,),
            ],
          )),
    );
  }
}
